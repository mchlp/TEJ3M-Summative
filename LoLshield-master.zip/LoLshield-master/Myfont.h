#ifndef Myfont_h
#define Myfont_h



#include <inttypes.h>

namespace Myfont
{
extern void Draw(int xval, unsigned char chr);
extern void Banner(int len, unsigned char* text);
}
#endif
